"""Private support package, not a Slicer module."""
