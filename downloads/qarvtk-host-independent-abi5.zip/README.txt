Experimental independent Slicer workspaces, host ABI 5.
Install with UPDATE-LIVE-PLUGIN.cmd from the matching branch, with Slicer closed.
The complete matching session-022c40b6 QAROS SDK is still required.
See docs/MULTIPLE_VOLUMES.md for usage, validation and limitations.
Build independent-startup-r2: negotiation no longer blocks ready frame streams.
